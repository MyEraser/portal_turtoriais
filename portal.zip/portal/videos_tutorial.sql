CREATE TABLE `apoioti_fanart`.`videos_tutorial`(
	id int primary not null,
	video_nome varchar(100) not null,
	video_descricao varchar(100) not null,
	video_code varchar(100) not null,
	video_dominio varchar(100) not null,
	ativo int(1) not null
);



