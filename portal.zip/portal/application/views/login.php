<html>
  <head>

 
<!------ Include the above in your HEAD tag ---------->
  </head>
<body id="LoginForm" class="caixa">
<div class="col-md-6">
    <div class="login-form col-md-12">
       <div class="main-div col-md-12">
          <div class="panel col-md-12">
             <h2>Administrar</h2>
             <p>Por favor, seu login e usuário</p>
          </div>
           <form class="panel col-md-12 box" id="Login" action="<?php echo base_url('videos/tipoLogin'); ?>" method="post">       
               <div class="form-group">
                   <input type="email" class="form-control" id="inputEmail" name="user_email" placeholder="Endereço de Email">
               </div>       
               <div class="form-group">
                   <input type="password" class="form-control" id="inputPassword" name="user_senha" placeholder="Senha">
               </div>
               <div class="forgot">
               <!-- <a href="http://127.0.0.1:8080/fanart/esqueciMinhaSenha/">Esqueceu sua senha?</a> -->
               </div>
               <button type="submit" class="btn btn-primary azul-login">Entrar</button>       
           </form>
           </div>
           <div class='footer col-md-12'>
             <p class="botto-text"><span style='font-size:15px;'> Informações importantes serão exibidas aqui</span></p>
             <p class="botto-text"><span style='font-size:15px;'> Assim poderá editar informações dos videos</span></p>
           </div>  
       </div>
     </div>
</div>
<?php 


?>

</body>
</html>
