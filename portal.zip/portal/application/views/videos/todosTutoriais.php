<!DOCTYPE html>
<html>
<head>
<title>Tutoriais</title>

<!-- Os videos são carregados dentro de pequenas caixinhas colapsáveis que por sua vez vem dentro dos iframes do youtube que instanciam por meio de um link embed -->
<input type='hidden' id='urlBase' value='<?php echo base_url(); ?>'>
</head>
<body>

  <?php 
//usar este esquema para listar outros videos prontos já na lateral da janela

  $numero = 0;
//      foreach($tutoriais_videos as $value){
//        ++$numero;
//         echo 
//         "<div class='container col-md-3' id='minhaDiv'>  
//           <button type='button' class='btn btn-block btn-info' data-toggle='collapse' data-target='#".$value['id']."'># ".$numero." - ".$value['video_nome']." - ".$value['video_dominio']."</button>
//           <div id='".$value['id']."' data-data_id_video='".$value['id']."' class='collapse'>                
//              <iframe class='' width='100%' height='315' src='https://www.youtube.com/embed/".$value['video_code']."' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>
//           </div>
//         </div>";
//       }
  ?>
  <!-- Os botões laterais devem atualizar o frame com o video segundo o titulo do tópico -->
  <div class='col-md-2 scroll'>
    <table class='table table-hover' id='tabela_topicos'>
      <thead>
          <th>Filtrar <i class='fas fa-search'></i>  <input type='text' class='pesquisar form-control' id='filtrar_videos' name='filtrar_conteudo' onkeyup='filtrar()'> </th>
      </thead>
      <tbody>
      <?php 
         foreach($tutoriais_videos as $value){

          $value['video_nome'];
          
          echo "
              <tr>
                <td>
                  <button class='btn brn-primary col-md-4 txt_align' data-id_video_slc='".$value['id']."' id='' onclick='carregaNovoItem(this)' data-id_video='' style='width:auto;'><i class='far fa-play-circle'></i> ".$value['video_nome']." </button>   
                </td>
              </tr>
          ";
         }
      ?>
          
      </tbody>
    </table>
  </div>
  <!-- carregar os videos aqui dentro -->
  <div class='col-md-8'>
  <center><img src="<?php echo base_url('vendors/imagens/loadingDog.gif') ?>" class='gif_loading' id='gif_loading' style='display:none'></center>
  
  <?php
  //os conteudos são atualizados dentro dessa DIV : id='conteudo_video'
   
      echo "<div class='' id='conteudo_video'>                
             <iframe class='video_visualizar' 
             width='100%' 
             height='498' 
             src='https://www.youtube.com/embed/".$value['video_code']."' 
             frameborder='0' 
             allow='accelerometer; 
             autoplay; 
             encrypted-media; 
             gyroscope; 
             picture-in-picture' 
             allowfullscreen>
             </iframe>
           </div>";

  ?>
  
  </div> 

  <!-- Tela central do espaço de visualização  --> 
  

  <div class='outros_videos col-md-2'>
       
    <table class='table table-hover'>
      <thead class='theader'>
          <th class='header'>Demais Tutoriais</th>
      </thead>
      <tbody class='corpo_tabela' >
      
      <!-- Aqui entra a coluna lateral direita onde carregam todas as miniaturas dos videos -->
      <?php 
         foreach($tutoriais_videos as $value){
          $value['video_nome'];
          
          echo "
              <tr>
                <td>
                  <div class='col-md-12'>
                    <label>".$value['video_nome']." </label>
                    <iframe class='video_visualizar' width='100%' height='50%' src='https://www.youtube.com/embed/".$value['video_code']."' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>   
                  </div>
                </td>
              </tr>
          ";
         }
      ?>
              
      </tbody>
    </table>
  </div> 

</body>
</html>  
