<!DOCTYPE html>
<html>
<head>
<title>Gerenciar</title>
<?php  

$sessionEmailUser = $this->session->userdata()['email'];
$sessionSenhaUser = $this->session->userdata()['senha'];

 if($sessionSenhaUser){
    echo "<script> console.log('user online') </script>";
  }else{

    header('location:'.base_url('videos/login'));
    echo "<script> console.log('user offline') </script>";

  }

?>
</head>
<body>
  <!-- <div class="container spacer">
    <a href="#" data-toggle="tooltip" data-placement="right" title="Para editar ou deletar clique no titulo que deseja!"><i class="far fa-question-circle" style="text-shadow:4px 4px 4px;color:green;font-size:30px;"></i></a>
  </div> -->
  <?php 

//  foreach($tutoriais_videos as $value){
//         echo 
//         "<div class='container' id='minhaDiv'>  
//           <button type='button' class='btn btn-block btn-info col-md-6' data-toggle='collapse' data-target='#".$value['id']."'>".$value['video_nome']." - ".$value['video_dominio']."</button>
//           <div id='".$value['id']."' class='collapse'>
//                 <iframe class='col-md-12' width='100%' height='315' src='https://www.youtube.com/embed/".$value['video_code']."' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>
//                 <center>
//                     <a href=".base_url('videos/deletarVideo/'.base64_encode($value["id"]).'')."><button class='btn btn-warning index-btn col-md-6' data-id_video='".$value['id']."'> <i class='fas fa-trash-alt'></i>Deletar?</button></a>
                    
//                     <a href=".base_url('videos/editarVideo/'.base64_encode($value["id"]).'')."><button class='btn btn-primary index-btn col-md-6' data-id_video='".$value['id']."' > <i class='fas fa-edit'></i> Editar?</button></a>
//                 </center>    
//           </div>
//         </div>";
//       }
?>

<!--  os videos com os botões para editar virão nesta sessão-->
<div class='col-md-6'>
    <table class='table table-hover' id='tabela_topicos'>
      <thead>
          <th>Filtrar <i class='fas fa-search'></i>  <input type='text' class='pesquisar form-control' id='filtrar_videos' name='filtrar_conteudo' onkeyup='filtrar()'> </th>
      </thead>
      <tbody>
      <?php 
         foreach($tutoriais_videos as $value){

          $value['video_nome'];
          
          echo "
              <tr>
                <td>
                  <button class='btn brn-primary col-md-12' data-id_video_slc='".$value['id']."' id='' onclick='carregaNovoItem(this)' data-id_video='' style='width:auto;'><i class='far fa-play-circle'></i> ".$value['video_nome']." </button>   
                  <div class='' id='conteudo_video'>                
             <iframe class='video_visualizar' 
             width='100%' 
             height='315' 
             src='https://www.youtube.com/embed/".$value['video_code']."' 
             frameborder='0' 
             allow='accelerometer; 
             autoplay; 
             encrypted-media; 
             gyroscope; 
             picture-in-picture' 
             allowfullscreen>
             </iframe>
           </div>
                  <center>
                    <a href=".base_url('videos/deletarVideo/'.base64_encode($value["id"]).'')."><button class='btn btn-warning index-btn col-md-6' data-id_video='".$value['id']."'> <i class='fas fa-trash-alt'></i></button></a>
                    <a href=".base_url('videos/editarVideo/'.base64_encode($value["id"]).'')."><button class='btn btn-primary index-btn col-md-6' data-id_video='".$value['id']."' > <i class='fas fa-edit'></i> </button></a>
                </center>
                </td>
              </tr>
          ";
         }
      ?>
          
      </tbody>
    </table>
  </div>



</body>
</html>  
