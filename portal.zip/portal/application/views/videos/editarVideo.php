<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>

<?php
$id_video        = "";
$video_nome      = "";
$video_descricao = "";
$video_code      = "";
$defaultYouTube  = "https://www.youtube.com/watch?v=";

        foreach($dados_video as $value){
               $id_video        =  $value['id'];
               $video_nome      =  $value['video_nome'];
               $video_descricao =  $value['video_descricao'];
               $video_code      =  $value['video_code'];

        }

?>

<body  id="body" class="container col-md-12">
    <div class="col-md-4">
            <form action="<?php echo base_url('videos/updateVideo') ?>" method="post">
            
            <div class="form">
                <label>Nome</label>
                <input type="text" value="<?php  echo $video_nome; ?>" class="form-control" name="video_nome" id="video_nome" required>
            </div>
             <div class="form">
                <label>Descricao</label>
                <input type="text" value="<?php echo $video_descricao; ?>" class="form-control" name="video_descricao" id="video_descricao" required>
            </div>
             <div class="form">
                <label>Alterar Link completo do video?</label>
                <input type="text" value="<?php echo $defaultYouTube.$video_code; ?>" class="form-control" name="video_code" id="video_code" required>
                <span style="font-size:12px">exemplo: https://www.youtube.com/watch?v=<b>yca6UsllwYs</b>
                </span>
                <input type="hidden" value="<?php echo base64_encode($id_video); ?>" name="video_id">
            </div>
            <br>
            <button class="btn btn-success"><i class="fas fa-redo-alt"></i> Atualizar</button>
            </form> 
    </div>
    <div class="container miniatura col-md-6">
        <iframe class="col-md-11" width="100%" height="40%" src="https://www.youtube.com/embed/<?php echo $video_code ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="false"></iframe>
         <div class="col-sm-1 icon"><i class="fas fa-eye" style='color:green'></i></div>
     </div>           
</body>
