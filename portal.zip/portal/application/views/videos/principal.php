<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php


  ?>
</head>
<body class="container col-md-12">
<div class="header_page col-md-12">
  <p class='title_page'> Ajuda <a href="#" data-toggle="tooltip" data-placement="right" title="Acesse O menu lateral para buscar tutoriais de ajuda!"><i class="far fa-question-circle" style="text-shadow:4px 4px 4px;color:white;font-size:30px;"></i></a>
</p>
</div>
<div id="mySidenav" class="sidenav">
  <form action="<?php echo base_url('videos/procurarTutorial'); ?>" method="post">
    
      <input type="type" class="blue" name="keyword"> <button class="btn_submit" type="submit"> <i class="fas fa-search"></i></button>
  </form>     
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a class="<?php ?> title" href="<?php echo base_url('videos/todosTutoriais'); ?>">Todos os Tutoriais</a>
  <?php
  if( (isset ($this->session->userdata()['email']) == TRUE) && (isset ($this->session->userdata()['senha']) == TRUE)){
    echo "<a href=".base_url('videos/novoTutorial').">Novo Tutorial</a>";
   }
   ?>
  <?php
  if( (isset ($this->session->userdata()['email']) == TRUE) && (isset ($this->session->userdata()['senha']) == TRUE)){
    echo "<a href=".base_url('videos/gerenciarVideos').">Editar ou Deletar</a>";
   }
   ?>
      
  <a class="<?php ?> title" href="<?php echo base_url('videos/login'); ?>">Login Adm</a>
   
   <?php 
     if( (isset ($this->session->userdata()['email']) == TRUE) && (isset ($this->session->userdata()['senha']) == TRUE)){ ?>
      <a href="<?php echo base_url('videos/encerra_session'); ?>"><button type="button" class="btn btn-danger btn-sair">Sair</button></a>
   
   <?php }
 
   ?>

  

</div>

<div id="main" class="container col-md-12">
 
  <span style="font-size:30px;cursor:pointer" onclick="openNav()"><button class="btn btn-menu"><i class="fas fa-ellipsis-v"></i> O que procura?</button> <button class='btn btn-menu' onclick='goBack()'> Voltar</button> </span> 
  
</div>
 <?php ?>
</body>
</html> 
