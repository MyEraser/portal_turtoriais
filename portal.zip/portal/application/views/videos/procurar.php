<!DOCTYPE html>
<html>
<head>
<title>Tutoriais</title>

</head>
<body>

  <?php 
   if(($videos) == NULL ){
             echo "<center><div class='container'><p class=''>Nenhum video encontrado</p> </div></center>";
         }
  ?>
    <table>

    
  <?php

  $numero = 0;
     foreach($videos as $value){
       ++$numero;
        echo 
        "<div class='container col-md-6 painel' id='minhaDiv'>  
          <button type='button' class='btn btn-block btn-info' data-toggle='collapse' data-target='#".$value['id']."'># ".$numero." - ".$value['video_nome']." - ".$value['video_dominio']."</button>
          <div id='".$value['id']."' data-data_id_video='".$value['id']."' class='collapse'>                
             <iframe class='' width='100%' height='315' src='https://www.youtube.com/embed/".$value['video_code']."' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>
          </div>
        </div>";
      }

      
  ?>

</body>
</html>  
