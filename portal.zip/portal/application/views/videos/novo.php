<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>

<?php

$sessionEmailUser = $this->session->userdata()['email'];
$sessionSenhaUser = $this->session->userdata()['senha'];

 if($sessionSenhaUser){
    echo "<script> console.log('user online') </script>";
  }else{

    header('location:'.base_url('videos/login'));
    echo "<script> console.log('user offline') </script>";

  }


?>

<body  id="body" class="container col-md-12">
    <div class="col-md-4">
            <form action="<?php echo base_url('videos/addVideo') ?>" method="post">
            
            <div class="form">
                <label>Nome</label>
                <input type="text" value="" class="form-control" name="video_nome" id="video_nome" required>
            </div>
             <div class="form">
                <label>Descricao</label>
                <input type="text" class="form-control" name="video_descricao" id="video_descricao" required>
            </div>
             <div class="form">
                <label>link completo do video</label>
                <input type="text" class="form-control" name="video_code" id="video_code" required>
                <span style="font-size:12px">exemplo: https://www.youtube.com/watch?v=<b>yca6UsllwYs</b>
                </span>
                <input type="hidden" value="" name="video_dominio">
            </div>
            <br>
            <button class="btn btn-success">Pronto</button>
            </form> 
    </div>
</body>