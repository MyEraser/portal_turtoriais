<div class="header_page col-md-12">
   
  <p class='white'>@blog desenvolvido para suporte a usuários - <span class="title_page">Apoio Ti</span> </p>
  
</div>