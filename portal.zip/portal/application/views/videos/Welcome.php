
<body class="container home">
    <h1 class="tlt" id="tlt">Precisa de ajuda? <?php echo $dominio; ?></h1>
    <p class="tlt"> Este é um blog de ajuda para auxiliar com o uso do sistema, para começar procure por algum tópico.</p>

</body>