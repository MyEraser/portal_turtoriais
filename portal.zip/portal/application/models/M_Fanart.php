<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Fanart extends CI_Model {


  public function addVideo($dados){
      
        $this->load->database();

        $this->db->insert('videos_tutorial',$dados);
    }


  public function listarVideos(){
       $this->load->database();

          return $this->db
          ->select('*')
          ->from('videos_tutorial')
          ->order_by("id","desc")
          ->get()
          ->result_array();
   }
    

    //por palavra chave
   public function localizaTutorial($keyword){
     $this->load->database();

     return $this->db
     ->select('*')
     ->from('videos_tutorial')
     ->order_by('id','desc')
     ->like('video_nome',$keyword)
     ->get()
     ->result_array();
   }  
    
    //por id
   public function localizaTutorial_($id_video){
     $this->load->database();

     return $this->db
     ->select('*')
     ->from('videos_tutorial')
     ->where('id',$id_video)
     ->get()
     ->result_array();
   }

   public function atualizaVideo($var_video_name,$var_video_descricao,$var_video_code,$var_video_id){
    $this->load->database();

    $this->db->set('video_nome', $var_video_name);
    $this->db->set('video_code', $var_video_code);
    $this->db->set('video_descricao', $var_video_descricao);
    $this->db->where('id', $var_video_id);
    return $this->db->update('videos_tutorial');
    
    }

    public function deletarVideo($id_video){
     $this->load->database();
     
     $this->db->delete('videos_tutorial',$id_video);



     
     
    }

    public function teste(){
      
        $testeDeBancoSecundario = $this->load->database('teste', TRUE);
        
        var_dump($testeDeBancoSecundario);
       

    }
    
    
}    