<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuarios extends CI_Controller {
	
     
	 public function __construct(){

     parent::__construct();
		$this->load->model('M_Fanart','fanart');
		$this->load->library('session');
    }
	
	public function index()
	{

		$this->load->view('videos/principal');
		$this->load->view('header',$data);
	}

	public function validarLogin(){
		
	}
}
	