<?php

/*
 Nome: Video Tutoriais
 Desenvolvido por: Adiel Esdras Cruz
 Version: PHP 7.1
 20/12/2018
     __    ||=======  =======   ||===\\ 
    //\\   ||         ||        ||    ||  ||    || =======
   //  \\  ||====     ||        ||====//  ||    ||      //
  //====\\ ||         ||        ||   \\   ||    ||     //
 //      \\||=======  ||        ||    \\  ||    ||    //
                      ========= ||     \\ ||====||   //====

 ==================================================Considerações========================================
 #nicialmente desenvolvi esse programinha para auxiliar usuários com suporte aos dados 
 #Não é um programa completo ainda, mas vou disponibilizar essa primeira versão Demo enquanto faço melhorias
*/


defined('BASEPATH') OR exit('No direct script access allowed');

class Videos extends CI_Controller {
	

	 public function __construct(){

     parent::__construct();
		$this->load->model('M_Fanart','fanart');
		$this->load->library('session');
    }
	
	public function index()
	{

		$this->load->view('videos/principal');
		$this->load->view('header',$data);
	}
	

	//atualiza o frame na tela com todos os videos
	public function atualizaFrame(){
		$id_video = $this->input->post('id_video_slc');

		$value = $this->fanart->localizaTutorial_($id_video);
		
		echo  "<iframe class='video_visualizar' 
             width='100%' 
             height='498' 
             src='https://www.youtube.com/embed/".$value[0]['video_code']."' 
             frameborder='0' 
             allow='accelerometer; 
             autoplay; 
             encrypted-media; 
             gyroscope; 
             picture-in-picture' 
             allowfullscreen>
             </iframe>";
		
		
	}

	//os videos são listados apenas pelo código principal de cada um deles, ai invés do link completo
	public function todosTutoriais(){
		$data['tutoriais_videos'] = $this->fanart->listarVideos();
		$this->load->view('header');
		$this->load->view('videos/principal',$data);
		$this->load->view('videos/todosTutoriais');
		
		return 0;
	}
	

	//apenas a view
	public function novoTutorial(){
		
		$this->load->view('header');
		$this->load->view('videos/principal');
		$this->load->view('videos/novo');	
		
		return 0;
	}
	

	//processa solicitação da view acima
	public function addVideo(){
		$this->load->view('header');
		$this->load->view('videos/principal');
		$this->load->view('videos/novo');		
		
		$dados = array();

		$dados['video_nome'] = 		$this->input->post('video_nome');
		$dados['video_descricao'] = $this->input->post('video_descricao');
		//captura o nome do controlador que deve corresponder ao dominio/cliente para armazenar no banco
		$dados['video_dominio'] = 	$this->uri->segment(1);
		
		$string_link = $this->input->post('video_code');
		//verificando o padrão google e extraindo o código do video que será utilizado parainstanciar no iframe
		$dados['video_code'] = 		$this->extractLink($string_link);
		
		$query = $this->fanart->addvideo($dados);
		
	}
	
	//function simples que verifica o padrão do youtube baseado na quantidade de caracteres
	public function extractLink($string_link){
		//os 32 primeiros são o dominio e link padrão
		$string_link = str_split($string_link, 32);
		//verifica se contém todos os caracteres na url pelo padrão
		if(strlen($string_link[0]) < 32 || strlen($string_link[1]) < 0 ){
			echo "<script> 
					alert('url incompleta');
					window.location.href = '".base_url('videos/novoTutorial')."';
					alert('Tente Novamente');
			      </script>";


// 		header('location:'.base_url('videos/novoTutorial'));							
		}else{
			$string_link = str_replace('https://www.youtube.com/watch?v=','',$string_link[1]);
		}
		
		//o que resta é o codigo final de cada video sem set de tempo inicial (start=x)
	    return $string_link;

	}


    public function procurarTutorial(){
       $keywords = $this->input->post('keyword');	
   
	   $data['videos'] = $this->fanart->localizaTutorial($keywords);	
	   
	   
	   $this->load->view('header');	
	   $this->load->view('videos/principal');
       $this->load->view('videos/procurar',$data);
     
   
    	return 0;
    }

    public function gerenciarVideos(){
       $data['tutoriais_videos'] = $this->fanart->listarVideos();
       $this->load->view('header');	
	   $this->load->view('videos/principal');
       $this->load->view('videos/gerenciarVideos', $data);

//        var_dump($_SESSION);
  	  
    	return 0;

    }
	
	//carrega a view com o form de atualização
    public function editarVideo(){
	   $id_video = base64_decode($this->uri->segment(3));	 
	   //devolve informações do video localizado	
	   $data['dados_video'] = $this->fanart->localizaTutorial_($id_video);

	   $this->load->view('header');	
	   $this->load->view('videos/principal');
       $this->load->view('videos/editarVideo',$data);
	     

    	return 0;
    }
	

	//recebe a solicitação de atualização de video
    public function updateVideo(){
		
     $var_video_name = $this->input->post('video_nome');
     $var_video_descricao = $this->input->post('video_descricao');
     $var_video_code = $this->extractLink($this->input->post('video_code'));
     $var_video_id   = base64_decode($this->input->post('video_id'));
     
     $data_update = array(
      'video_nome' 		=> $var_video_name,
      'video_descricao' => $var_video_descricao,
      'video_code' 		=> $var_video_code,
      'video_id'   		=> $var_video_id
       );

     $debug = $this->fanart->atualizaVideo($var_video_name,$var_video_descricao,$var_video_code,$var_video_id);
		
     
      header('location: '.base_url('videos/gerenciarVideos'));
   }

   public function deletarVideo(){
   
       $var_video_id   = array('id' => base64_decode($this->uri->segment(3)) );
       $boolquery = $this->fanart->deletarVideo($var_video_id);
	   
	   echo "<script> alert('Video deletado'); </script>";
	   header('location:'.base_url('videos/gerenciarVideos'));    
	  
       
   }
	
   //Somente administradores poderão realizar alterações	
   public function login(){
   	   $this->load->view('header');	
       $this->load->view('login');
   }
	
	//método que será utilizado somente para ad-emes para controlar a edição dos links dos videos	
   //userTeste	
   public function tipoLogin(){
   	
  		$email = $this->input->post('user_email');
		$senha = $this->input->post('user_senha');		
		$senha = md5($senha);
		
			
		if($email == "eraser@eraser" && $senha == md5('userTeste100200')){
			
			$_SESSION['email'] = $email;
			$_SESSION['senha'] = $senha;
			
			$vetor_user = array('email' => $email, 'senha'=> $senha);			
			$debug = $this->session->set_userdata($vetor_user);
			header('location:'.base_url('videos/redirect')); 

		}else{
			echo "<script> alert('Dados de acesso incorretos, contate o webmaster'); </script>";

			echo "aguarde...";
			header('location: '.base_url('videos/login'));
		}

   	
   }
	

   public function redirect(){
   	 $this->gerenciarVideos();   	 
   }
	
	

   public function encerra_session(){
	$vetor = array(
		'email',
		'senha'
	);
	
	$this->session->unset_userdata($vetor);

	header('location:'.base_url('videos/todosTutoriais'));

   	return 0;
   }
	
}

